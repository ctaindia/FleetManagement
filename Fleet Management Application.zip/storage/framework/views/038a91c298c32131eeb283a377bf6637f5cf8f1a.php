

<?php $__env->startSection('title', 'Profile detail'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="height-100 bg-light">
    <div class="container dashboard-container">
        <div class="row">
           <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item" aria-current="page">Profile</li>
                  
                </ol>
              </nav>
           </div>
        </div>

        <div class="row">
            <div class="col-md-3">
                <img src="<?php echo e(auth()->user()->image); ?>" alt="User image" width="200">
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12 pb-4">
                        <h4>Basic Details</h4>
                        <p><b>Name: </b> <?php echo e(auth()->user()->name); ?></p>
                        <p><b>Email: </b> <?php echo e(auth()->user()->email); ?></p>
                        <p><b>Contact: </b> <?php echo e(auth()->user()->mobile); ?></p>
                    </div>
                    <?php if(auth()->user()->user_type === 2): ?>
                    
                    <?php endif; ?>
                    <div class="col-md-3">
                        <div class="col-12 text-center">
                            <a href="<?php echo e(route('user.changeprofile')); ?>" class="primary-button">Edit Profile</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="col-12 text-center">
                            <a href="<?php echo e(route('user.changepassword')); ?>" class="primary-button">Change Password</a>
                        </div>
                    </div>
                </div>
            </div>
                
        </div>
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fleet Management Application\resources\views/modules/profile/detail.blade.php ENDPATH**/ ?>