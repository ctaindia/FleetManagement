<div class="l-navbar" id="nav-bar">
    <nav class="nav">
        <div> <a href="#" class="nav_logo"> <i class='bx bx-layer nav_logo-icon'></i> <span class="nav_logo-name"><?php echo e(config('app.name')); ?></span> </a>
            <div class="nav_list"> 
                <a href="<?php echo e(route('dashboard')); ?>" class="nav_link <?php echo e(request()->routeIs('dashboard')? 'active' : ''); ?>"> <i class='bx bx-grid-alt nav_icon'></i> <span class="nav_name">Dashboard</span> </a> 
                <?php if(auth()->user()->user_type === 1): ?>
                <a href="<?php echo e(route('admin.vendor.list')); ?>" class="nav_link <?php echo e(request()->routeIs('admin.vendor*')? 'active' : ''); ?>"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Vendors</span> </a>
                <?php endif; ?> 
                <a href="<?php echo e(route('admin.driver.list')); ?>" class="nav_link <?php echo e(request()->routeIs('admin.driver*')? 'active' : ''); ?>"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Drivers</span> </a> 
                <a href="<?php echo e(route('admin.vehicle.type.list')); ?>" class="nav_link <?php echo e(request()->routeIs('admin.vehicle.type*')? 'active' : ''); ?>"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Vehicle Type</span> </a>
                <a href="<?php echo e(route('admin.vehicles.list')); ?>" class="nav_link <?php echo e(request()->routeIs('admin.vehicles*')? 'active' : ''); ?>"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Vehicle</span> </a>
                <a href="<?php echo e(route('admin.fuel.list')); ?>" class="nav_link <?php echo e(request()->routeIs('admin.fuel*')? 'active' : ''); ?>"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Fuel</span> </a> 
            </div>
        </div>
        <a href="#" class="nav_link" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"> <i class='bx bx-log-out nav_icon'></i> <span class="nav_name">SignOut</span> </a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </nav>
</div><?php /**PATH D:\Fleet Management Application\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>