<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name')); ?>-<?php echo $__env->yieldContent('title'); ?></title>

    <!--css links-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.css')); ?>">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
</head>
<body id="body-pd" class="<?php echo e(request()->routeIs('login')? 'login-body' : ''); ?>">
    <?php if(!request()->routeIs('login')): ?>
        <!-- header -->
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- sidebar -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php endif; ?>
    
    <!--Container Main start-->
    <?php echo $__env->yieldContent('main-content'); ?>

    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script>
        <?php if(Session::has('Success')): ?>
            swal('Success','<?php echo e(Session::get('Success')); ?>', 'success');
        <?php elseif(Session::has('Errors')): ?>
            swal('Error','<?php echo e(Session::get('Errors')); ?>', 'error');
        <?php endif; ?>
    </script>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH D:\Fleet Management Application\resources\views/layouts/master.blade.php ENDPATH**/ ?>