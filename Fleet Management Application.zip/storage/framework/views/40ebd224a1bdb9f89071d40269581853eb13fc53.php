
<?php $__env->startSection('title', 'Vehicle list'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="height-100 bg-light">
    <div class="container dashboard-container">
        <div class="row">
           <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb align-items-center">
                  <li class="breadcrumb-item" aria-current="page">Dashboard</li>
                  <li class="breadcrumb-item" aria-current="page"><i class="bx bx-chevron-right"></i></li>
                  <li class="breadcrumb-item" aria-current="page">Vehicle</li>
                  <li class="breadcrumb-item" aria-current="page"><i class="bx bx-chevron-right"></i></li>
                  <li class="breadcrumb-item active" aria-current="page">Listings</li>
                </ol>
              </nav>
           </div>
        </div>
        <div class="row mt-0">
            <div class="col-lg-4">
                <div class="card d-flex flex-row justify-content-between align-items-center p-3">
                    <div class="card-left">
                        <h5 class="yellow-text mb-0">Total</h5>
                        <p><span>230</span></p>
                    </div>
                    <div class="card-right">
                        <div class="card-image-wrapper yellow">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card d-flex flex-row justify-content-between align-items-center p-3">
                    <div class="card-left">
                        <h5 class="red-text mb-0">Total</h5>
                        <p><span>230</span></p>
                    </div>
                    <div class="card-right">
                        <div class="card-image-wrapper red">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="card d-flex flex-row justify-content-between align-items-center p-3">
                    <div class="card-left">
                        <h5 class="blue-text mb-0">Total</h5>
                        <p><span>230</span></p>
                    </div>
                    <div class="card-right">
                        <div class="card-image-wrapper blue">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mt-5">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-2 text-center">
                        <a href="<?php echo e(route('admin.vehicles.create')); ?>" class="primary-button">Add</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-6">
                        <select name="per-page" id="" class="select-heading">
                            <option value="10">10/page</option>
                            <option value="10">20/page</option>
                        </select>
                    </div>
                    <div class="col-lg-6">
                        <div class="input-group">
                            <input type="text" placeholder="Search.....">
                            <button><i class='bx bx-search-alt-2'></i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <th>Sl.</th>
                        <th>Driver</th>
                        <th>Image</th>
                        <th>Maker</th>
                        <th>Engiene Model</th>
                        <th>Vehicle Model</th>
                        <th>Horse Power</th>
                        <th>Vehicle Type</th>
                        <th>mielege</th>
                        <th>License No</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><a href="<?php echo e(route('admin.driver.list', ['id' => base64_encode($vehicle->driver->id)])); ?>"><?php echo e($vehicle->driver->name); ?></a></td>
                            <td><img src="<?php echo e(asset($vehicle->vehicle_image)); ?>" alt="driver image" width="70"></td>
                            <td><?php echo e($vehicle->maker_name); ?></td>
                            <td><?php echo e($vehicle->engine_model); ?></td>
                            <td><?php echo e($vehicle->vehicle_model); ?></td>
                            <td><?php echo e($vehicle->vehicle_hp); ?></td>
                            <td><a href="<?php echo e(route('admin.vehicle.type.list', ['id' => base64_encode($vehicle->vehicleType->id)])); ?>"><?php echo e($vehicle->vehicleType->name); ?></a></td>
                            <td><?php echo e($vehicle->mielege); ?></td>
                            <td><?php echo e($vehicle->liscence_no); ?></td>
                            <td>
                                <span class="action-button m-1"><a href="<?php echo e(route('admin.vehicles.edit', ['id' => base64_encode($vehicle->id)])); ?>"><i class='bx bxs-edit'></i></a></span>
                                <span class="action-button m-1"><a onclick="return confirm('are you sure?')" href="<?php echo e(route('admin.vehicles.delete', ['id' => base64_encode($vehicle->id)])); ?>"><i class='bx bxs-trash'></i></a></span>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($vehicles) === 0): ?>
                            <tr>
                                <td colspan="10" class="text-center">No data</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fleet Management Application\resources\views/modules/vehicle/vehicles/list.blade.php ENDPATH**/ ?>