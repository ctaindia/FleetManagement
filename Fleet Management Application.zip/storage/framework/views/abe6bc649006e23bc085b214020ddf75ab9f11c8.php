
<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="height-100 bg-light">
    <div class="container dashboard-container">
        <div class="row">
           <div class="col-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item" aria-current="page">Dashboard</li>
                </ol>
              </nav>
           </div>
        </div>
        <?php if(auth()->user()->user_type === 1): ?>
        <div class="row mt-5 card-container">
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image yellow">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Total Vehicle</p>
                        <h5 class="text-right"><span class="yellow-text"><?php echo e($totalVehicle); ?></span></h5>
                   </div>
                   <div class="card-bottom">
                       <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
                   </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image red">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Active Vehicles</p>
                        <h5 class="text-right"><span class="red-text"><?php echo e($activeVehicle); ?></span></h5>
                   </div>
                   <div class="card-bottom">
                       <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                   </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image blue">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Total Vendor</p>
                        <h5 class="text-right"><span class="blue-text"><?php echo e($totalVendor); ?></span></h5>
                   </div>
                   <div class="card-bottom">
                        <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image green">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Total KMs Driven</p>
                        <h5 class="text-right"><span class="green-text">00.00</span></h5>
                   </div>
                   <div class="card-bottom">
                        <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="row mt-5">
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image green">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Today's KM</p>
                        <h5 class="text-right"><span class="green-text">00.00</span></h5>
                   </div>
                   <div class="card-bottom">
                        <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php if(auth()->user()->user_type === 2): ?>
        <div class="row mt-5 card-container">
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image yellow">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Total Vehicle</p>
                        <h5 class="text-right"><span class="yellow-text"><?php echo e($totalVehicle); ?></span></h5>
                   </div>
                   <div class="card-bottom">
                       <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit. </p>
                   </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image red">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Active Vehicles</p>
                        <h5 class="text-right"><span class="red-text"><?php echo e($activeVehicle); ?></span></h5>
                   </div>
                   <div class="card-bottom">
                       <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                   </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image green">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Total KMs Driven</p>
                        <h5 class="text-right"><span class="green-text">00.00</span></h5>
                   </div>
                   <div class="card-bottom">
                        <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3">
                <div class="card">
                   <div class="card-upper">
                        <div class="card-image blue">
                            <img src="<?php echo e(asset('assets/image/folder.png')); ?>" alt="">
                        </div>
                        <p>Today's KM</p>
                        <h5 class="text-right"><span class="blue-text">00.00</span></h5>
                   </div>
                   <div class="card-bottom">
                        <p class="text-muted"><i class='bx bxs-purchase-tag'></i> Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Fleet Management Application\resources\views/modules/dashboard.blade.php ENDPATH**/ ?>