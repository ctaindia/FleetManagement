<header class="header" id="header">
    <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
    <div class="header_img"><a href="<?php echo e(route('profile.detail')); ?>"> <img src="<?php echo e(asset(auth()->user()->image)); ?>" alt=""></a> </div>
</header><?php /**PATH D:\Fleet Management Application\resources\views/layouts/header.blade.php ENDPATH**/ ?>