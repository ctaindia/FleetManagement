<header class="header" id="header">
    <div class="header_toggle"> <i class='bx bx-menu' id="header-toggle"></i> </div>
    <div class="header_img"><a href="{{route('profile.detail')}}"> <img src="{{asset(auth()->user()->image)}}" alt=""></a> </div>
</header>